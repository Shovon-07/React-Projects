import React from "react";

//___ Css ___//
import "./Profile.scss";

const Profile = () => {
  return <div className="Profile">Profile</div>;
};

export default Profile;
